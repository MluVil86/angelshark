﻿namespace angelshark.Models
{
    public class AS_Subscriber
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string? MiddleName { get; set; } 
        public string LastName { get; set; } = string.Empty;
        public float? MobileNumber { get; set; } 
        public bool Active { get; set; } = true;
        public DateTime Created { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }

        public virtual List<AS_GroupMember>? GroupMembers { get; set; }
    }
}
