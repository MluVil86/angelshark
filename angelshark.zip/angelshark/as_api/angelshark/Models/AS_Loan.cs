﻿

using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace angelshark.Models
{
    public class AS_Loan
    {
        public int Id { get; set; }
        [Required]
        public int GroupMember_Id { get; set; }
        public DateTime Loan_Date { get; set; }
        public DateTime End_Date { get; set; }
        public decimal Loan_Amount { get; set; }
        public decimal Interest_Amount { get; set; }
        public double Interest_Percentage { get; set; }
        public decimal Monthly_Payment_Amount { get; set; }
        public decimal Principal_Paid { get; set; }
        public decimal Interest_Paid { get; set; }        
        public decimal Outstanding_Principal { get; set; }
        public decimal Outstanding_Interest { get; set; }
        public bool InArrears { get; set; }
        public DateTime? Last_Payment_Date { get; set; }
        public bool Active { get; set; } = true;
        public DateTime Created { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }

        [JsonIgnore]
        public virtual AS_GroupMember GroupMember { get; set; }
        public virtual List<AS_LoanPayment> LoanPayments { get; set; }
        public virtual List<As_LoanDefault> LoanDefaults { get; set; }

    }
}
