﻿using Microsoft.EntityFrameworkCore;

namespace angelshark.Models
{
    public class ASContext : DbContext
    {
        public ASContext(DbContextOptions<ASContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AS_Subscriber>()
                .HasMany(a => a.GroupMembers)
                .WithOne(s => s.Subscriber)
                .HasForeignKey(a => a.Subscriber_Id);

            modelBuilder.Entity<AS_Group>()
                .HasMany(a => a.GroupMembers)
                .WithOne(s => s.Group)
                .HasForeignKey(a => a.Group_Id);
                
            modelBuilder.Entity<AS_GroupMember>()
                .HasMany(a => a.Loans)
                .WithOne(s => s.GroupMember)
                .HasForeignKey(a => a.GroupMember_Id);

            modelBuilder.Entity<AS_Loan>()
                .HasMany(a => a.LoanPayments)
                .WithOne(s => s.Loan)
                .HasForeignKey(a => a.Loan_Id);

            modelBuilder.Entity<AS_Loan>()
                .HasMany(a => a.LoanDefaults)
                .WithOne(s => s.Loan)
                .HasForeignKey(a => a.Loan_Id);

            modelBuilder.Seed();
        }

        public DbSet<AS_Subscriber> Subscribers { get; set; }
        public DbSet<AS_Group> Groups { get; set; }
        public DbSet<AS_GroupMember> GroupMembers { get; set; }
        public DbSet<AS_Loan> Loans { get; set; }
        public DbSet<AS_LoanPayment> LoanPayments { get; set; }
        public DbSet<As_LoanDefault> LoanDefaults { get; set; }
    }

    
}
