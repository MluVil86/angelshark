﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace angelshark.Models
{
    public class AS_GroupMember
    {
        public int Id { get; set; }
        [Required]
        public int Group_Id { get; set; }
        [Required]
        public int Subscriber_Id { get; set; }
        public DateTime Join_Date { get; set; } = DateTime.Now;
        public DateTime? Exit_Date { get; set; }
        public decimal Commitment_Amount { get; set; } = 0;
        public bool Active { get; set; } = true;
        public DateTime Created { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }

        [JsonIgnore]
        public virtual AS_Group? Group { get; set; }
        [JsonIgnore]
        public virtual AS_Subscriber? Subscriber { get; set; }

        public virtual List<AS_Loan>? Loans { get; set; }
    }
}
