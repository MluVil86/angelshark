﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace angelshark.Models
{
    public class AS_LoanPayment
    {
        public int Id { get; set; }
        [Required]
        public int Loan_Id { get; set; }
        public DateTime Payment_Date { get; set; }
        public decimal Amount_Paid { get; set; }
        public bool Active { get; set; } = true;
        public DateTime Created { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }

        [JsonIgnore]
        public virtual AS_Loan Loan { get; set; }
    }
}
