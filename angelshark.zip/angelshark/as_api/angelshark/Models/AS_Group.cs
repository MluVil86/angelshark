﻿namespace angelshark.Models
{
    public class AS_Group
    {
        public int Id { get; set; }
        public Guid Group_Id { get; set; } = new Guid();
        public string Alias { get; set; } = string.Empty;
        public DateTime InitiationDate { get; set; } = DateTime.Now;
        public DateTime? TerminationDate { get; set; }
        public double Minimum_Interest { get; set; } = 0.5;
        public bool Active { get; set; } = true;
        public bool Global { get; set; } = false;
        public DateTime Created { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }

        public virtual List<AS_GroupMember>? GroupMembers { get; set; }
    }
}
