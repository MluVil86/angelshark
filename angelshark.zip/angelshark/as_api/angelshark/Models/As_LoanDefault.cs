﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace angelshark.Models
{
    public class As_LoanDefault
    {
        public int Id { get; set; }
        [Required]
        public int Loan_Id { get; set; }
        public DateTime Default_Date { get; set; }
        public decimal? Under_Payment_Amount { get; set; }
        public bool Active { get; set; } = true;
        public DateTime Created { get; set; } = DateTime.Now;
        public string CreatedBy { get; set; } = string.Empty;
        public DateTime? Modified { get; set; }
        public string? ModifiedBy { get; set; }
        [JsonIgnore]
        public virtual AS_Loan Loan { get; set; }
    }
}
