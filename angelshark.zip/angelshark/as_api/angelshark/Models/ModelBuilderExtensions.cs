﻿using Microsoft.EntityFrameworkCore;

namespace angelshark.Models
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AS_Subscriber>().HasData(
                new AS_Subscriber { Id = 1, FirstName="Sandile", MiddleName="Mlondie", LastName="Nzima", MobileNumber = 26876181045, Created=DateTime.Now, CreatedBy= "26876181045", Modified=null, ModifiedBy=null },
                new AS_Subscriber { Id = 2, FirstName = "Sihle", MiddleName = "Sammy", LastName = "Matsebula", MobileNumber = 26876080003, Created = DateTime.Now, CreatedBy = "26876080003", Modified = null, ModifiedBy = null },
                new AS_Subscriber { Id = 3, FirstName = "Nancy", MiddleName = "Setsabile", LastName = "Motsa", MobileNumber = 26876153105, Created = DateTime.Now, CreatedBy = "26876153105", Modified = null, ModifiedBy = null },
                new AS_Subscriber { Id = 4, FirstName = "Zoe", MiddleName = "Banele", LastName = "Thusi", MobileNumber = 26876274000, Created = DateTime.Now, CreatedBy = "26876274000", Modified = null, ModifiedBy = null },
                new AS_Subscriber { Id = 5, FirstName = "Tembi", MiddleName = "Njabuliso", LastName = "Ncube", MobileNumber = 26876291047, Created = DateTime.Now, CreatedBy = "26876291047", Modified = null, ModifiedBy = null },
                new AS_Subscriber { Id = 6, FirstName = "Nompumelelo", MiddleName = "Sandra", LastName = "Mhlongo", MobileNumber = 26876221010, Created = DateTime.Now, CreatedBy = "26876221010", Modified = null, ModifiedBy = null }, 
                new AS_Subscriber { Id = 7, FirstName = "Delisa", MiddleName = "Simphiwe", LastName = "Nxumalo", MobileNumber = 26876372910, Created = DateTime.Now, CreatedBy = "26876372910", Modified = null, ModifiedBy = null },
                new AS_Subscriber { Id = 8, FirstName = "Nolwazi", MiddleName = "Thabile", LastName = "Maphalala", MobileNumber = 26878111000, Created = DateTime.Now, CreatedBy = "26878111000", Modified = null, ModifiedBy = null },
                new AS_Subscriber { Id = 9, FirstName = "Luyanda", MiddleName = "Lindiwe", LastName = "Mamba", MobileNumber = 26876061000, Created = DateTime.Now, CreatedBy = "26876061000", Modified = null, ModifiedBy = null },
                new AS_Subscriber { Id = 10, FirstName = "Thembelihle", MiddleName = "Khetsiwe", LastName = "Maziya", MobileNumber = 26876021090, Created = DateTime.Now, CreatedBy = "26876021090", Modified = null, ModifiedBy = null });

            modelBuilder.Entity<AS_Group>().HasData(
                new AS_Group { Id = 1, Group_Id = Guid.NewGuid(), InitiationDate = DateTime.Now, TerminationDate = null, Minimum_Interest = 0.5, Alias = "Jabulani Saving Co-op", Active = true, Global = false, Created = DateTime.Now, CreatedBy = "26876181045", Modified = null, ModifiedBy = null },
                new AS_Group { Id = 2, Group_Id = Guid.NewGuid(), InitiationDate = DateTime.Now, TerminationDate = null, Minimum_Interest = 1.5, Alias = "Thaba-Bosiu Saving Group", Active = true, Global = false, Created = DateTime.Now, CreatedBy = "26878111000", Modified = null, ModifiedBy = null },
                new AS_Group { Id = 3, Group_Id = Guid.NewGuid(), InitiationDate = DateTime.Now, TerminationDate = null, Minimum_Interest = 2.5, Alias = "AS Global Savings", Active = true, Global = true, Created = DateTime.Now, CreatedBy = "angelshark_admin", Modified = null, ModifiedBy = null });

            modelBuilder.Entity<AS_GroupMember>().HasData(
                new AS_GroupMember { Id = 1, Group_Id = 1, Subscriber_Id = 1, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 600, Created = DateTime.Now, CreatedBy = "26876181045", Modified = null, ModifiedBy = null},
                new AS_GroupMember { Id = 2, Group_Id = 2, Subscriber_Id = 1, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 900, Created = DateTime.Now, CreatedBy = "26876181045", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 3, Group_Id = 3, Subscriber_Id = 1, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 850, Created = DateTime.Now, CreatedBy = "26876181045", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 4, Group_Id = 2, Subscriber_Id = 2, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 400, Created = DateTime.Now, CreatedBy = "26876080003", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 5, Group_Id = 2, Subscriber_Id = 3, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 1600, Created = DateTime.Now, CreatedBy = "26876153105", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 6, Group_Id = 1, Subscriber_Id = 4, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 6000, Created = DateTime.Now, CreatedBy = "26876274000", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 7, Group_Id = 3, Subscriber_Id = 5, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 6600, Created = DateTime.Now, CreatedBy = "26876291047", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 8, Group_Id = 2, Subscriber_Id = 6, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 300, Created = DateTime.Now, CreatedBy = "26876221010", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 9, Group_Id = 1, Subscriber_Id = 7, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 100, Created = DateTime.Now, CreatedBy = "26876372910", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 10, Group_Id = 3, Subscriber_Id = 7, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 200, Created = DateTime.Now, CreatedBy = "26876372910", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 11, Group_Id = 1, Subscriber_Id = 8, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 8000, Created = DateTime.Now, CreatedBy = "26878111000", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 12, Group_Id = 2, Subscriber_Id = 8, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 250, Created = DateTime.Now, CreatedBy = "26878111000", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 13, Group_Id = 3, Subscriber_Id = 8, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 250, Created = DateTime.Now, CreatedBy = "26878111000", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 14, Group_Id = 1, Subscriber_Id = 9, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 100, Created = DateTime.Now, CreatedBy = "26876061000", Modified = null, ModifiedBy = null },
                new AS_GroupMember { Id = 15, Group_Id = 3, Subscriber_Id = 9, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 120, Created = DateTime.Now, CreatedBy = "26876061000", Modified = null, ModifiedBy = null },               
                new AS_GroupMember { Id = 16, Group_Id = 1, Subscriber_Id = 10, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 1600, Created = DateTime.Now, CreatedBy = "26876021090", Modified = null, ModifiedBy = null },               
                new AS_GroupMember { Id = 17, Group_Id = 2, Subscriber_Id = 10, Join_Date = DateTime.Now, Exit_Date = null, Commitment_Amount = 1600, Created = DateTime.Now, CreatedBy = "26876021090", Modified = null, ModifiedBy = null });            
        }
    }
}
