﻿namespace angelshark.ViewModel.NewFolder
{
    public class VM_LoanParameters
    {
        public decimal loan_amount { get; set; } 
        public float mobilenumber { get; set; }
        public string group_alias { get; set; } = String.Empty;
    }
}
