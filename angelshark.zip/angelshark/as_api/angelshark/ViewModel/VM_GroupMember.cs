﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace angelshark.ViewModel
{
    public class VM_GroupMember
    {        
        public string? Group { get; set; }        
        public string? Subscriber { get; set; }
        public float? MobileNumber { get; set; }
        public DateTime Join_Date { get; set; } = DateTime.Now;
        public DateTime? Exit_Date { get; set; }
        public decimal Commitment_Amount { get; set; } = 0;
        public bool Active { get; set; } = true;
   
    }
}
