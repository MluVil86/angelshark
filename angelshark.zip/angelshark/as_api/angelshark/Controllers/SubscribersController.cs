﻿using angelshark.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace angelshark.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubscribersController : ControllerBase
    {
        private readonly ASContext _context;
        
        public SubscribersController(ASContext context)
        {
            _context = context;
            _context.Database.EnsureCreated();
        }
        
        [HttpGet]
        public IEnumerable<AS_Subscriber> GetAllSubscribers()
        {
            return _context.Subscribers.ToList();
        }

        [HttpGet("{msisdn}")]
        public async Task<ActionResult> GetSubscriber(float msisdn)
        {
            var group = await _context.Subscribers.FirstOrDefaultAsync(s => s.MobileNumber == msisdn);
            if (group == null)
            {
                return NotFound();
            }
            return Ok(group);
        }

        [HttpPost]
        public async Task<ActionResult<AS_Subscriber>> PostSubscriber(AS_Subscriber subscriber)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            var _subscriber = _context.Subscribers.Any(x => x.MobileNumber == subscriber.MobileNumber);
            if (!_subscriber)
            {
                _context.Subscribers.Add(subscriber);
                await _context.SaveChangesAsync();
            }
            else
            {
                return BadRequest("The subscriber is already registered.");
            }
            
            return CreatedAtAction(
                "GetSubscriber",
                new { id = subscriber.Id },
                subscriber
                );
        }

    


    }
}
