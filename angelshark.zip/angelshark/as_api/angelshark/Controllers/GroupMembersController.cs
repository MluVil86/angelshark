﻿using angelshark.Models;
using angelshark.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace angelshark.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupMembersController : ControllerBase
    {
        private readonly ASContext _context;
        public GroupMembersController(ASContext context)
        {
            _context = context;
            _context.Database.EnsureCreated();
        }
        
        [HttpGet]
        public List<VM_GroupMember> GetAllGroupMembers()
        {
            var groupmembers = _context.GroupMembers.Include(g => g.Group).Include(g => g.Subscriber).OrderBy(g => g.Group_Id).ToList();
            List<VM_GroupMember> members = new List<VM_GroupMember>();

            foreach (var item in groupmembers)
            {
                VM_GroupMember gm = new VM_GroupMember()
                {
                    Group = item.Group.Alias,
                    Subscriber = item.Subscriber.FirstName + " " + item.Subscriber.LastName,
                    MobileNumber = item.Subscriber.MobileNumber,
                    Join_Date = item.Join_Date,
                    Exit_Date = item.Exit_Date,
                    Commitment_Amount = item.Commitment_Amount,
                    Active = item.Active
                };

                members.Add(gm);
            }
            
            return members;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> GetGroupMember(int id)
        {
            var groupmember = await _context.GroupMembers.Include(g => g.Group).Include(g => g.Subscriber).FirstOrDefaultAsync(g => g.Id ==id);
            if (groupmember == null)
            {
                return NotFound();
            }

            VM_GroupMember member = new VM_GroupMember()
            {
                Group = groupmember.Group.Alias,
                Subscriber = groupmember.Subscriber.FirstName + " " + groupmember.Subscriber.LastName,
                MobileNumber = groupmember.Subscriber.MobileNumber,
                Join_Date = groupmember.Join_Date,
                Exit_Date = groupmember.Exit_Date,
                Commitment_Amount = groupmember.Commitment_Amount,
                Active = groupmember.Active
            };

            return Ok(member);
        }

        [HttpGet("Group/{alias}")]
        public async Task<ActionResult> GetGroupMembersByGroup(string alias)
        {
            var groupmember = await _context.GroupMembers.Include(g => g.Group).Include(g => g.Subscriber).Where(g => g.Group.Alias == alias).ToListAsync();
            
            if (groupmember == null)
            {
                return NotFound();
            }

            List<VM_GroupMember> members = new List<VM_GroupMember>();
            foreach (var item in groupmember)
            {
                VM_GroupMember gm = new VM_GroupMember()
                {
                    Group = item.Group.Alias,
                    Subscriber = item.Subscriber.FirstName + " " + item.Subscriber.LastName,
                    MobileNumber = item.Subscriber.MobileNumber,
                    Join_Date = item.Join_Date,
                    Exit_Date = item.Exit_Date,
                    Commitment_Amount = item.Commitment_Amount,
                    Active = item.Active
                };

                members.Add(gm);
            }
            return Ok(members);
        }

        [HttpGet("Subscriber/{msisdn}")]
        public async Task<ActionResult<List<VM_GroupMember>>> GetGroupMembersBySubscribers(float msisdn)
        {
            var groupmember = await _context.GroupMembers.Include(g => g.Group).Include(g => g.Subscriber).Where(g => g.Subscriber.MobileNumber == msisdn).ToListAsync();
            if (groupmember == null)
            {
                return NotFound();
            }
            List<VM_GroupMember> member = new List<VM_GroupMember>();
            foreach (var item in groupmember)
            {
                VM_GroupMember gm = new VM_GroupMember()
                {
                    Group = item.Group.Alias,
                    Subscriber = item.Subscriber.FirstName + " " + item.Subscriber.LastName,
                    MobileNumber = item.Subscriber.MobileNumber,
                    Join_Date = item.Join_Date,
                    Exit_Date = item.Exit_Date,
                    Commitment_Amount = item.Commitment_Amount,
                    Active = item.Active
                };

                member.Add(gm);
            }

            return Ok(member);
        }

    }
}
