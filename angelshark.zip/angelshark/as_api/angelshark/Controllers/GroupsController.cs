﻿using angelshark.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace angelshark.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupsController : ControllerBase
    {
        private readonly ASContext _context;
        public GroupsController(ASContext context)
        {
            _context = context;
            _context.Database.EnsureCreated();
        }
        
        [HttpGet]
        public IEnumerable<AS_Group> GetAllGroups()
        {
            return _context.Groups.ToList();
        }

        [HttpGet("{alias}")]
        public async Task<ActionResult>GetGroup(string alias)
        {
            var group = await _context.Groups.FirstOrDefaultAsync(g => g.Alias == alias);
            if (group == null)
            {
                return NotFound();
            }
            return Ok(group);
        }

        [HttpPost]
        public async Task<ActionResult<AS_Group>> PostGroup(AS_Group group)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(group);
            }

            var _group = _context.Groups.Any(a => a.Alias.ToLower().Trim() == group.Alias.ToLower().Trim());

            if (!_group)
            {
                _context.Groups.Add(group);
                await _context.SaveChangesAsync();
            }
            else
            {
                return BadRequest("Group already exists.");
            }
            
            return CreatedAtAction(
                "GetGroup",
                new { id = group.Id },
                group
                );
        }       
    }
}
