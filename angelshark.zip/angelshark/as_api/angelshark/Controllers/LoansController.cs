﻿using angelshark.Models;
using angelshark.ViewModel;
using angelshark.ViewModel.NewFolder;
using Angelshark;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace angelshark.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoansController : ControllerBase
    {
        private readonly ASContext _context;
        public LoansController(ASContext context)
        {
            _context = context;
            _context.Database.EnsureCreated();
        }
        
        [HttpGet("Predict")]
        public float LoanAmount(float mobile)
        {

            //Load sample data
            var sampleData = new LoanPredict.ModelInput()
            {
                Mobilenumber = mobile,
                Loaddate = @"2022-02-12 19:23:49",
            };

            //Load model and predict output
            var result = LoanPredict.Predict(sampleData);

            return result.Score;
        }

        [HttpPost]
        public async Task<ActionResult<VM_Loan>> PostLoan(VM_LoanParameters loanParameters)
        {


            if (loanParameters.loan_amount <= Convert.ToDecimal(LoanAmount(loanParameters.mobilenumber)))
            {
                var subscriber = _context.Subscribers.Where(s => s.MobileNumber == loanParameters.mobilenumber).FirstOrDefaultAsync();
                var group = _context.Groups.Where(g => g.Alias.Trim() == loanParameters.group_alias.Trim()).FirstOrDefaultAsync();

                if (subscriber == null || group == null)
                {
                    return BadRequest("Group or Subscriber could not be found");
                }
                else
                {                       
                    int? groupmember = _context.GroupMembers.Where(g => g.Group_Id == group.Result.Id && g.Subscriber_Id == subscriber.Result.Id).FirstOrDefaultAsync().Result.Id;
                    if (groupmember == null)
                    {
                        return BadRequest($"Subscriber {loanParameters.mobilenumber} is not part of {loanParameters.group_alias} group.");
                    }
                    else
                    {
                        decimal repayment = (loanParameters.loan_amount + decimal.Multiply(loanParameters.loan_amount, 3.5M/100)) / 6;
                        AS_Loan loan = new AS_Loan
                        {
                            GroupMember_Id = (int)groupmember,
                            Loan_Date = DateTime.Now,
                            End_Date = DateTime.Now.AddMonths(6),
                            Loan_Amount = loanParameters.loan_amount,
                            Interest_Amount = decimal.Multiply(loanParameters.loan_amount, 3.5M/100),
                            Interest_Percentage = 3.5,
                            Monthly_Payment_Amount = repayment,
                            Principal_Paid = 0,
                            Interest_Paid = 0,
                            Outstanding_Principal = loanParameters.loan_amount,
                            Outstanding_Interest = decimal.Multiply(loanParameters.loan_amount, 3.5M/100),
                            InArrears = false,
                            Last_Payment_Date = null,
                            Active = true,
                            Created = DateTime.Now,
                            CreatedBy = loanParameters.mobilenumber.ToString(),
                            Modified = null,
                            ModifiedBy = null
                        };

                        _context.Add(loan);
                        await _context.SaveChangesAsync();

                        VM_Loan vm_loan = new VM_Loan()
                        {
                            GroupMember = loan.GroupMember.Subscriber.FirstName + " " + loan.GroupMember.Subscriber.LastName,
                            Group = loan.GroupMember.Group.Alias,
                            Loan_Date = loan.Loan_Date,
                            End_Date = loan.End_Date,
                            Loan_Amount= loan.Loan_Amount,
                            Interest_Amount = loan.Interest_Amount,
                            Total_Amount = loan.Loan_Amount + loan.Interest_Amount,
                            Interest_Percentage = loan.Interest_Percentage,
                            Monthly_Payment_Amount = loan.Monthly_Payment_Amount,
                            Principal_Paid = loan.Principal_Paid,
                            Interest_Paid = loan.Interest_Paid,
                            Outstanding_Principal = loan.Outstanding_Principal,
                            Outstanding_Interest = loan.Outstanding_Interest,
                            InArrears = loan.InArrears,
                            Last_Payment_Date = loan.Last_Payment_Date,
                            Active = loan.Active
                        };
                                               
                        return vm_loan;
                    }
                }
            }
            else
            {
                return BadRequest($"You only qualify for {LoanAmount(loanParameters.mobilenumber)} or less");
            }
            
        }

        [HttpGet("Group/{alias}")]
        public async Task<ActionResult> GetLoansByGroup(string alias)
        {
            var grouploans = await _context.Loans.Include(l => l.GroupMember)
                                 .ThenInclude(l => l.Group)
                                 .Where(g => g.GroupMember.Group.Alias == alias)
                                 .Select(l => new 
                                 {
                                     Group = l.GroupMember.Group.Alias,
                                     Subscriber = l.GroupMember.Subscriber.FirstName + " " + l.GroupMember.Subscriber.LastName,
                                     MobileNumber = l.GroupMember.Subscriber.MobileNumber,
                                     l.Loan_Date,
                                     l.End_Date,
                                     l.Loan_Amount,
                                     l.Interest_Amount,
                                     l.Interest_Percentage,
                                     l.Monthly_Payment_Amount,
                                     l.Principal_Paid,
                                     l.Outstanding_Principal,
                                     l.Outstanding_Interest,
                                     l.InArrears,
                                     l.Last_Payment_Date,
                                     l.Active
                                 }).ToListAsync();

            if (grouploans == null)
            {
                return NotFound();
            }
            return Ok(grouploans);
        }

        [HttpGet("Subscriber/{msisdn}")]
        public async Task<ActionResult> GetLoansBySubscribers(float msisdn)
        {
            var groupmember = await _context.Loans
                                            .Include(l => l.GroupMember)
                                            .ThenInclude(l => l.Subscriber)
                                            .Where(g => g.GroupMember.Subscriber.MobileNumber == msisdn)
                                            .Select(l => new
                                            {
                                                Subscriber = l.GroupMember.Subscriber.FirstName + " " + l.GroupMember.Subscriber.LastName,
                                                MobileNumber = l.GroupMember.Subscriber.MobileNumber,
                                                l.Loan_Date,
                                                l.End_Date,
                                                l.Loan_Amount,
                                                l.Interest_Amount,
                                                l.Interest_Percentage,
                                                l.Monthly_Payment_Amount,
                                                l.Principal_Paid,
                                                l.Outstanding_Principal,
                                                l.Outstanding_Interest,
                                                l.InArrears,
                                                l.Last_Payment_Date,
                                                l.Active
                                            }).ToListAsync();
            if (groupmember == null)
            {
                return NotFound();
            }
            return Ok(groupmember);
        }

        [HttpGet]
        public IEnumerable<AS_Loan> GetAllLoans()
        {
            return _context.Loans.ToList();
        }
    }
}
