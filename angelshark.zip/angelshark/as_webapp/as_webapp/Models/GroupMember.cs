﻿using System.ComponentModel.Design;

namespace as_webapp.Models
{
    public class GroupMember
    {
        public string? Group { get; set; }
        public string? Subscriber { get; set; }
        public double? MobileNumber { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? ExitDate { get; set; }
        public decimal? CommitmentAmount { get; set; }
        public bool? Active { get; set; }
    }
}
