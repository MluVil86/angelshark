﻿namespace as_webapp.Models
{
    public class Loan
    {
        public string? Subscriber { get; set; }
        public double? MobileNumber { get; set; }
        public DateTime? LoanDate { get; set; }
        public DateTime? EndDate { get; set; }
        public decimal? LoanAmount { get; set; }
        public decimal? InterestAmount { get; set; }
        public decimal? InterestPercentage { get; set; }
        public decimal? MonthlyPaymentAmount { get; set; }
        public decimal? PrincipalPaid { get; set; }
        public decimal? OutstandingPrincipal { get; set; }
        public decimal? OutstandingInterest { get; set; }
        public bool? InArrears { get; set; }
        public DateTime? LastPaymentDate { get; set; }
        public bool? Active { get; set; }

    }
}
