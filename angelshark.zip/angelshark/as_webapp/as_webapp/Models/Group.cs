﻿namespace as_webapp.Models
{
    public class Group
    {
        public int Id { get; set; }
        public Guid Group_Id { get; set; } = new Guid();
        public string Alias { get; set; } = string.Empty;
        public DateTime InitiationDate { get; set; } = DateTime.Now;
        public DateTime? TerminationDate { get; set; }
        public double Minimum_Interest { get; set; } = 0.5;
        public bool Active { get; set; } = true;
        public bool Global { get; set; } = false;

        public virtual List<GroupMember>? GroupMembers { get; set; }
        public virtual List<Loan>? Loans { get; set; }
    }
}
