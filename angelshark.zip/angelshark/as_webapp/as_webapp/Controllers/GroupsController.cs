﻿using as_webapp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System;
using System.Text.Json;

namespace as_webapp.Controllers
{    
    public class GroupsController : Controller
    {
        public static string baseurl = "https://localhost:7082/";
        // GET: GroupController
        public ActionResult Index()
        {
            var client = new RestClient(baseurl);
            var sendRequest = new RestRequest("/api/Groups", Method.Get);                                    
            var sendResponse = client.Execute(sendRequest);

            var jsonDocument = JsonDocument.Parse(sendResponse.Content);
            JsonElement jsonElement = jsonDocument.RootElement;

            var jsonGroups = jsonElement.EnumerateArray();
            List<Group> groups = new List<Group>();
            while (jsonGroups.MoveNext())
            {
                Group group = new Group();
               
                var jsonGroup = jsonGroups.Current;
                group.Id = jsonGroup.GetProperty("id").GetInt16();
                group.Group_Id = jsonGroup.GetProperty("group_Id").GetGuid();
                group.Alias = jsonGroup.GetProperty("alias").GetString();
                group.InitiationDate = jsonGroup.GetProperty("initiationDate").GetDateTime();
                
                if (jsonGroup.GetProperty("terminationDate").GetRawText() != "null")
                {
                    group.TerminationDate = jsonGroup.GetProperty("terminationDate").GetDateTime();
                }
                else
                {
                    group.TerminationDate = null;
                }
                 
                group.Minimum_Interest = jsonGroup.GetProperty("minimum_Interest").GetDouble();
                group.Active = jsonGroup.GetProperty("active").GetBoolean();
                group.Global = jsonGroup.GetProperty("global").GetBoolean();

                groups.Add(group);               
            }
        
            return View(groups);
        }

        // GET: GroupController/Details/5
        public ActionResult Details(string alias)
        {
            var client = new RestClient(baseurl);
            var sendRequest = new RestRequest($"/api/Groups/{alias}", Method.Get);            
            var sendResponse = client.Execute(sendRequest);
            decimal FundTotal = 0M;
            decimal FundLoans = 0M;
            var jsonDocument = JsonDocument.Parse(sendResponse.Content);
            JsonElement jsonElement = jsonDocument.RootElement;

            Group group = new Group();

            group.Id = jsonElement.GetProperty("id").GetInt16();
            group.Group_Id = jsonElement.GetProperty("group_Id").GetGuid();
            group.Alias = jsonElement.GetProperty("alias").GetString();
            group.InitiationDate = jsonElement.GetProperty("initiationDate").GetDateTime();

            if (jsonElement.GetProperty("terminationDate").GetRawText() != "null")
            {
                group.TerminationDate = jsonElement.GetProperty("terminationDate").GetDateTime();
            }
            else
            {
                group.TerminationDate = null;
            }

            group.Minimum_Interest = jsonElement.GetProperty("minimum_Interest").GetDouble();
            group.Active = jsonElement.GetProperty("active").GetBoolean();
            group.Global = jsonElement.GetProperty("global").GetBoolean();

            client = new RestClient(baseurl);
            sendRequest = new RestRequest($"/api/GroupMembers/Group/{alias}", Method.Get);
            sendResponse = client.Execute(sendRequest);

            jsonDocument = JsonDocument.Parse(sendResponse.Content);
            jsonElement = jsonDocument.RootElement;

            var jsonGroups = jsonElement.EnumerateArray();
            List<GroupMember>? groupmember = new List<GroupMember>();
            

            while (jsonGroups.MoveNext())
            {
                GroupMember group_member = new GroupMember();
                
                var jsonGroup = jsonGroups.Current;
                group_member.Group = jsonGroup.GetProperty("group").GetString();
                group_member.Subscriber = jsonGroup.GetProperty("subscriber").GetString();
                group_member.JoinDate = jsonGroup.GetProperty("join_Date").GetDateTime();
                var bigger  = jsonGroup.GetProperty("mobileNumber").GetSingle();
                group_member.MobileNumber = double.Parse(bigger.ToString());
                              
                if (jsonGroup.GetProperty("exit_Date").GetRawText() != "null")
                {
                    group_member.ExitDate = jsonGroup.GetProperty("exit_Date").GetDateTime();
                }
                else
                {
                    group_member.ExitDate = null;
                }

                group_member.CommitmentAmount = jsonGroup.GetProperty("commitment_Amount").GetDecimal();
                group_member.Active = jsonGroup.GetProperty("active").GetBoolean();

                FundTotal += jsonGroup.GetProperty("commitment_Amount").GetDecimal();
                groupmember.Add(group_member);
            }

            client = new RestClient(baseurl);
            sendRequest = new RestRequest($"/api/Loans/Group/{alias}", Method.Get);
            sendResponse = client.Execute(sendRequest);

            jsonDocument = JsonDocument.Parse(sendResponse.Content);
            jsonElement = jsonDocument.RootElement;

            var jsonLoans = jsonElement.EnumerateArray();
            List<Loan>? loans = new List<Loan>();

            while (jsonLoans.MoveNext())
            {
                Loan loan = new Loan();

                var jsonLoan = jsonLoans.Current;
                loan.Subscriber = jsonLoan.GetProperty("subscriber").GetString();
                var bigger = jsonLoan.GetProperty("mobileNumber").GetSingle();
                loan.MobileNumber = double.Parse(bigger.ToString());
                loan.LoanDate = jsonLoan.GetProperty("loan_Date").GetDateTime();
                loan.EndDate = jsonLoan.GetProperty("end_Date").GetDateTime();
                loan.LoanAmount = jsonLoan.GetProperty("loan_Amount").GetDecimal();
                loan.InterestAmount = jsonLoan.GetProperty("interest_Amount").GetDecimal();
                loan.InterestPercentage = jsonLoan.GetProperty("interest_Percentage").GetDecimal();
                loan.MonthlyPaymentAmount = jsonLoan.GetProperty("monthly_Payment_Amount").GetDecimal();
                loan.PrincipalPaid = jsonLoan.GetProperty("principal_Paid").GetDecimal();
                loan.OutstandingPrincipal = jsonLoan.GetProperty("outstanding_Principal").GetDecimal();
                loan.OutstandingInterest = jsonLoan.GetProperty("outstanding_Interest").GetDecimal();
                loan.InArrears = jsonLoan.GetProperty("inArrears").GetBoolean();
                loan.Active = jsonLoan.GetProperty("active").GetBoolean();

                if (jsonLoan.GetProperty("last_Payment_Date").GetRawText() != "null")
                {
                    loan.LastPaymentDate = jsonLoan.GetProperty("last_Payment_Date").GetDateTime();
                }
                else
                {
                    loan.LastPaymentDate = null;
                }

                FundLoans += jsonLoan.GetProperty("loan_Amount").GetDecimal();
                loans.Add(loan);
            }

            ViewBag.GroupFund = FundTotal;
            ViewBag.GroupLoans = FundLoans;
            ViewBag.AvailableFunds = FundTotal - FundLoans;
            group.GroupMembers = groupmember;
            group.Loans = loans;
            return View(group);
        }

        // GET: GroupController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: GroupController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                DateTime? date = null;               
                var client = new RestClient(baseurl);
                List<object>? list = null;

                var sendRequest = new RestRequest($"/api/Groups/", Method.Post);
                sendRequest.AddJsonBody(new
                {                    
                    id = 0,
                    group_Id = Guid.NewGuid(),
                    alias = collection["Alias"].ToString(),
                    initiationDate = collection["InitiationDate"].ToString(),
                    terminationDate = date,
                    minimum_Interest = collection["Minimum_Interest"].ToString(),
                    active = true,
                    global = false,
                    created = DateTime.Now,
                    createdBy = "angelshark_admin",
                    modified = date,
                    modifiedBy = string.Empty,
                    groupMembers = list
                }); 

                var sendResponse = client.Execute(sendRequest);

                return RedirectToAction(nameof(Details), new {alias = collection["Alias"] });
            }
            catch
            {
                return View();
            }
        }

        // GET: GroupController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: GroupController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: GroupController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: GroupController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
