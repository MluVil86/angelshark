﻿using as_webapp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using System;
using System.Text.Json;

namespace as_webapp.Controllers
{    
    public class SubscribersController : Controller
    {
        public static string baseurl = "https://localhost:7082/";
        // GET: GroupController
        public ActionResult Index()
        {
            var client = new RestClient(baseurl);
            var sendRequest = new RestRequest("/api/Subscribers", Method.Get);                                    
            var sendResponse = client.Execute(sendRequest);

            var jsonDocument = JsonDocument.Parse(sendResponse.Content);
            JsonElement jsonElement = jsonDocument.RootElement;

            var jsonGroups = jsonElement.EnumerateArray();
            List<Subscriber> subscribers = new List<Subscriber>();
            while (jsonGroups.MoveNext())
            {
                Subscriber subscriber = new Subscriber();
               
                var jsonGroup = jsonGroups.Current;
                subscriber.Id = jsonGroup.GetProperty("id").GetInt16();
                subscriber.FirstName = jsonGroup.GetProperty("firstName").GetString();
                subscriber.MiddleName = jsonGroup.GetProperty("middleName").GetString();
                subscriber.LastName = jsonGroup.GetProperty("lastName").GetString();
                var bigger = jsonGroup.GetProperty("mobileNumber").GetSingle();
                subscriber.MobileNumber = double.Parse(bigger.ToString());

                subscribers.Add(subscriber);               
            }
        
            return View(subscribers);
        }

        // GET: GroupController/Details/5
        public ActionResult Details(string msisdn)
        {
            var client = new RestClient(baseurl);
            var sendRequest = new RestRequest($"/api/Subscribers/{msisdn}", Method.Get);            
            var sendResponse = client.Execute(sendRequest);
            decimal FundTotal = 0M;
            var jsonDocument = JsonDocument.Parse(sendResponse.Content);
            JsonElement jsonElement = jsonDocument.RootElement;

            Subscriber subscriber = new Subscriber();

            subscriber.Id = jsonElement.GetProperty("id").GetInt16();
            subscriber.FirstName = jsonElement.GetProperty("firstName").GetString();
            subscriber.MiddleName = jsonElement.GetProperty("middleName").GetString();
            subscriber.LastName = jsonElement.GetProperty("lastName").GetString();
            subscriber.Active = jsonElement.GetProperty("active").GetBoolean();
            var bigger = jsonElement.GetProperty("mobileNumber").GetSingle();
            subscriber.MobileNumber = double.Parse(bigger.ToString());

            client = new RestClient(baseurl);
            sendRequest = new RestRequest($"/api/GroupMembers/Subscriber/{msisdn}", Method.Get);
            sendResponse = client.Execute(sendRequest);

            jsonDocument = JsonDocument.Parse(sendResponse.Content);
            jsonElement = jsonDocument.RootElement;

            var jsonGroups = jsonElement.EnumerateArray();
            List<GroupMember>? groupmembers = new List<GroupMember>();
            

            while (jsonGroups.MoveNext())
            {
                GroupMember groupmember = new GroupMember();
                
                var jsonGroup = jsonGroups.Current;
                groupmember.Group = jsonGroup.GetProperty("group").GetString();
                groupmember.Subscriber = jsonGroup.GetProperty("subscriber").GetString();
                groupmember.JoinDate = jsonGroup.GetProperty("join_Date").GetDateTime();
                bigger  = jsonGroup.GetProperty("mobileNumber").GetSingle();
                groupmember.MobileNumber = double.Parse(bigger.ToString());
                              
                if (jsonGroup.GetProperty("exit_Date").GetRawText() != "null")
                {
                    groupmember.ExitDate = jsonGroup.GetProperty("exit_Date").GetDateTime();
                }
                else
                {
                    groupmember.ExitDate = null;
                }

                groupmember.CommitmentAmount = jsonGroup.GetProperty("commitment_Amount").GetDecimal();
                groupmember.Active = jsonGroup.GetProperty("active").GetBoolean();

                FundTotal += jsonGroup.GetProperty("commitment_Amount").GetDecimal();
                groupmembers.Add(groupmember);
            }

            ViewBag.GroupFund = FundTotal;
            subscriber.GroupMembers = groupmembers;
            return View(subscriber);
        }

        public ActionResult Loans(string msisdn)
        {
            var client = new RestClient(baseurl);
            var sendRequest = new RestRequest($"/api/Subscribers/{msisdn}", Method.Get);
            var sendResponse = client.Execute(sendRequest);
            decimal FundTotal = 0M;
            var jsonDocument = JsonDocument.Parse(sendResponse.Content);
            JsonElement jsonElement = jsonDocument.RootElement;

            Subscriber subscriber = new Subscriber();

            subscriber.Id = jsonElement.GetProperty("id").GetInt16();
            subscriber.FirstName = jsonElement.GetProperty("firstName").GetString();
            subscriber.MiddleName = jsonElement.GetProperty("middleName").GetString();
            subscriber.LastName = jsonElement.GetProperty("lastName").GetString();
            subscriber.Active = jsonElement.GetProperty("active").GetBoolean();
            var bigger = jsonElement.GetProperty("mobileNumber").GetSingle();
            subscriber.MobileNumber = double.Parse(bigger.ToString());

            client = new RestClient(baseurl);
            sendRequest = new RestRequest($"/api/Loans/Subscriber/{msisdn}", Method.Get);
            sendResponse = client.Execute(sendRequest);

            jsonDocument = JsonDocument.Parse(sendResponse.Content);
            jsonElement = jsonDocument.RootElement;

            var jsonGroups = jsonElement.EnumerateArray();
            List<Loan> ?  loans = new List<Loan>();

            while (jsonGroups.MoveNext())
            {
                Loan loan = new Loan();

                var jsonGroup = jsonGroups.Current;
                loan.Subscriber = jsonGroup.GetProperty("subscriber").GetString();
                bigger = jsonGroup.GetProperty("mobileNumber").GetSingle();
                loan.MobileNumber = double.Parse(bigger.ToString());
                loan.LoanDate = jsonGroup.GetProperty("loan_Date").GetDateTime();
                loan.EndDate = jsonGroup.GetProperty("end_Date").GetDateTime();
                loan.LoanAmount = jsonGroup.GetProperty("loan_Amount").GetDecimal();
                loan.InterestAmount = jsonGroup.GetProperty("interest_Amount").GetDecimal();
                loan.InterestPercentage = jsonGroup.GetProperty("interest_Percentage").GetDecimal();
                loan.MonthlyPaymentAmount = jsonGroup.GetProperty("monthly_Payment_Amount").GetDecimal();
                loan.PrincipalPaid = jsonGroup.GetProperty("principal_Paid").GetDecimal();
                loan.OutstandingPrincipal = jsonGroup.GetProperty("outstanding_Principal").GetDecimal();
                loan.OutstandingInterest = jsonGroup.GetProperty("outstanding_Interest").GetDecimal();
                loan.InArrears = jsonGroup.GetProperty("inArrears").GetBoolean();
                loan.Active = jsonGroup.GetProperty("active").GetBoolean();

                if (jsonGroup.GetProperty("last_Payment_Date").GetRawText() != "null")
                {
                    loan.LastPaymentDate = jsonGroup.GetProperty("last_Payment_Date").GetDateTime();
                }
                else
                {
                    loan.LastPaymentDate = null;
                }
             
                FundTotal += jsonGroup.GetProperty("loan_Amount").GetDecimal();
                loans.Add(loan);
            }

            ViewBag.GroupFund = FundTotal;
            subscriber.Loans = loans;
            return View(subscriber);
        }

        // GET: GroupController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: GroupController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                DateTime? date = null;               
                var client = new RestClient(baseurl);
                List<object>? list = null;

                var sendRequest = new RestRequest($"/api/Subscribers/", Method.Post);
                sendRequest.AddJsonBody(new
                {                    
                    id = 0,
                    firstName = collection["FirstName"].ToString(),
                    middleName = collection["MiddleName"].ToString(),
                    lastName = collection["LastName"].ToString(),
                    mobileNumber = collection["MobileNumber"].ToString(),                    
                    active = true,                 
                    created = DateTime.Now,
                    createdBy = "angelshark_admin",
                    modified = date,
                    modifiedBy = string.Empty,
                    groupMembers = list
                }); 

                var sendResponse = client.Execute(sendRequest);

                return RedirectToAction(nameof(Details), new { msisdn = collection["MobileNumber"] });
            }
            catch
            {
                return View();
            }
        }

        // GET: GroupController/Create
        public ActionResult LoanApply(string msisdn, string group)
        {
            var client = new RestClient(baseurl);
            var sendRequest = new RestRequest($"/api/Loans/Predict/?mobile={msisdn}", Method.Get);
            var sendResponse = client.Execute(sendRequest);            
            var jsonDocument = JsonDocument.Parse(sendResponse.Content);
            JsonElement jsonElement = jsonDocument.RootElement;
            
            ViewBag.MaxAmount = jsonElement.GetDecimal();
            ViewBag.MSISDN = msisdn;
            ViewBag.Group = group;

            return View();
        }

        // POST: GroupController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LoanApply(IFormCollection collection)
        {
            try
            {                
                var client = new RestClient(baseurl);
                  
                var sendRequest = new RestRequest($"/api/Loans/", Method.Post);
                sendRequest.AddBody(new
                {
                    loan_amount = Convert.ToDecimal(collection["Amount"].ToString()),
                    group_alias = collection["Group"].ToString(),
                    mobilenumber = Convert.ToDecimal(collection["MobileNumber"])
                });

                var sendResponse = client.Execute(sendRequest);

                return RedirectToAction(nameof(Loans), new { msisdn = collection["MobileNumber"] });
            }
            catch
            {
                return View();
            }
        }

        // GET: GroupController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: GroupController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: GroupController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: GroupController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
