﻿namespace as_webapp.ViewModel
{
    public class VMLoan
    {
        public double Amount { get; set; }
        public string MobileNumber { get; set; }
        public string Group { get; set; }
    }
}
